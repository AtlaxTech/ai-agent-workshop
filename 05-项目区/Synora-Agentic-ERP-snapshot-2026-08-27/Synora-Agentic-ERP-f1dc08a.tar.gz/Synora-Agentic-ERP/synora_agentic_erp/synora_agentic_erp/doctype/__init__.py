"""Synora-owned Frappe records."""
