"""Immutable Gateway call audit."""
